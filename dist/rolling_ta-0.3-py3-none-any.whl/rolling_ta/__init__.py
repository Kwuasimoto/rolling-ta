from .__main__ import test_pypi

__all__ = ["test_pypi"]
