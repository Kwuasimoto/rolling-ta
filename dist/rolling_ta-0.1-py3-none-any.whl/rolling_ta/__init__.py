from .main import test_pypi

__all__ = ["test_pypi"]
