def test_pypi():
    print("Hello from Kwausimoto!")
