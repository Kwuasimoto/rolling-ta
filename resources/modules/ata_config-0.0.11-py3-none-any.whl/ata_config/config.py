import json
import os
from pathlib import Path
from typing import Any

import importlib.resources as pkg

from dotenv import dotenv_values


class Config:
    def __init__(self):
        import dotenv

        dotenv.load_dotenv(override=True)
        self._production = (
            "PRODUCTION" in os.environ and os.environ["PRODUCTION"] is True
        )
        self._testing = "TESTING" in os.environ and os.environ["TESTING"] is True

        # Create the config file
        import ata_config

        try:
            with pkg.path(ata_config, "config.json") as cfg_path:
                if not cfg_path.exists() or os.path.getsize(cfg_path) == 0:
                    with open(cfg_path, "w") as f:
                        json.dump({}, f)
                    print("Initialized new config.json in ata_config module.")
        except FileNotFoundError:
            with pkg.path(ata_config, ".") as pkg_path:
                cfg_path = os.path.join(pkg_path, "config.json")
                with open(cfg_path, "w") as f:
                    json.dump({}, f)
                print("Initialized new config.json in ata_config module.")

    def get(self, key: str):
        try:
            import ata_config

            cfg_path = pkg.files(ata_config) / "config.json"

            with cfg_path.open("r") as f:
                return json.load(f)[key]

        except Exception as e:
            print(f"Failed to read config -> \n{e}")

    def env(self, key: str):
        try:
            return os.environ.get(key)

        except Exception as e:
            print(f"Failed to read env -> \n{e}")


def add_config(key: str, value: Any):
    # try:
    import ata_config

    cfg_path = pkg.files(ata_config) / "config.json"

    with cfg_path.open("r") as f:
        cfg: dict = json.load(f)
        if key not in cfg:
            cfg[key] = value

    with cfg_path.open("w") as f:
        json.dump(cfg, f, indent=4)

    # except Exception as e:
    #     print(f"add_config threw an exception \n{e}")


def has_config(key: str):
    try:
        import ata_config

        cfg_path = pkg.files(ata_config) / "config.json"

        with cfg_path.open("r") as f:
            cfg: dict = json.load(f)
            return key in cfg

    except json.decoder.JSONDecodeError as e:
        # Assumes json failed to load due to 0 chars.
        return False


def _parse_filename_and_ext(path: Path):
    c_file = path.parts[-1]
    c_ext = f".{c_file.rsplit('.', maxsplit=1)[-1]}"
    return c_file + c_ext


def _load_env_file(path: Path, exclude: list[str] = [], overwrite=False):
    print(f"LOADING FILE: [{path}]")
    if _parse_filename_and_ext(path) in exclude:
        print(f"IGNORING: {path.parts[-1]}")

    env_vars = dotenv_values(path)
    print(f"ENV VARS: {env_vars}")
    for key, value in env_vars.items():
        if (key and value) and (overwrite or not has_config(key)):
            print(f"ADDING CONFIG: [{key}, {value}]")
            add_config(key, value)


def _load_env_dir(path: Path, exclude: list[str] = [], overwrite=False):
    """Attempts to recursively load all environment files from .env directory"""
    if os.path.isfile(os.path.abspath(path)):
        _load_env_file(path)
    else:
        print(f"LOADING DIR: {path}")
        for path_name in os.listdir(path):
            _load_env_dir(Path(os.path.join(path, path_name)))


def load_config(
    path: Path = None, exclude: list[str] = [], target=".env", overwrite=False
):
    """Loads and builds internalized .config file using .env files"""
    path = Path(os.getcwd() if path is None else path) / target

    if path.is_file():
        _load_env_file(path, exclude, overwrite)

    elif path.is_dir():
        _load_env_dir(path, exclude, overwrite)


cfg = Config()
