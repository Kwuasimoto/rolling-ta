import atexit
import logging
from os import path
import os
from pathlib import Path
from typing import Type


class Logger(logging.Logger):

    _handlers: tuple[logging.Handler]

    def __init__(
        self,
        name="ata_logger",
        dirname="logs",
        logname="app.log",
        test_logname="app_test.log",
    ):
        self.testing = os.getenv("TESTING") == True
        self.production = os.getenv("PRODUCTION") == True

        format = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
        level = logging.DEBUG if not self.production else logging.INFO

        super().__init__(name, level=level)

        std_formatter = logging.Formatter(format)

        console_handler = logging.StreamHandler()
        console_handler.setLevel(level=level)
        console_handler.setFormatter(std_formatter)
        self.addHandler(console_handler)
        dir = Path.cwd() / dirname
        dir.mkdir(exist_ok=True)
        filename = path.join(dir, logname if not self.testing else test_logname)
        file_handler = logging.FileHandler(filename)
        file_handler.setLevel(level=level)
        file_handler.setFormatter(std_formatter)
        self.addHandler(file_handler)

        self._handlers = (console_handler, file_handler)

        if not self.testing:
            atexit.register(self.shutdown)

    def shutdown(self):
        # self.debug("Shutdown", self)
        # self.debug(
        #     "_______________________________________________________________________",
        #     self,
        # )
        for handler in self._handlers:
            self.removeHandler(handler)

    def parse_location(self, obj: str | Type):
        if isinstance(obj, str):
            return obj
        return obj.__class__.__name__

    def debug(
        self, msg, *args, exc_info=None, stack_info=False, stacklevel=1, extra=None
    ):
        """Debug log message.

        Params:
            args: (tuple) - class is assumed to be the first tuple object.

        """
        if self.isEnabledFor(logging.DEBUG):
            if len(args):
                (cls,) = args
                super().debug(
                    f"[{self.parse_location(cls)}] - {msg}",
                    exc_info=exc_info,
                    stack_info=stack_info,
                    stacklevel=stacklevel,
                    extra=extra,
                )
                return
            else:
                super().debug(
                    f"[GLOBAL] - {msg}",
                    exc_info=exc_info,
                    stack_info=stack_info,
                    stacklevel=stacklevel,
                    extra=extra,
                )

    def info(
        self, msg, *args, exc_info=None, stack_info=False, stacklevel=1, extra=None
    ):
        """Info log message.

        Params:
            args: (tuple) - class is assumed to be the first tuple object.

        """
        if self.isEnabledFor(logging.INFO):
            if len(args):
                (cls,) = args
                super().info(
                    f"[{self.parse_location(cls)}] - {msg}",
                    exc_info=exc_info,
                    stack_info=stack_info,
                    stacklevel=stacklevel,
                    extra=extra,
                )
                return
            else:
                super().info(
                    f"[GLOBAL] - {msg}",
                    exc_info=exc_info,
                    stack_info=stack_info,
                    stacklevel=stacklevel,
                    extra=extra,
                )

    def error(
        self, msg, *args, exc_info=None, stack_info=False, stacklevel=1, extra=None
    ):
        """Info log message.

        Params:
            args: (tuple) - class is assumed to be the first tuple object. error second.

        """
        if self.isEnabledFor(logging.ERROR):
            if len(args) == 1:
                (cls,) = args
                super().error(
                    f"""{[self.parse_location(cls)]}
    Message:\n
        {msg}\n       
    """,
                    (None),
                    exc_info=exc_info,
                    stack_info=stack_info,
                    stacklevel=stacklevel,
                    extra=extra,
                )
            elif len(args) == 2:
                cls, err = args
                super().error(
                    f"""{[self.parse_location(cls)]}
    Message:\n
        {msg}\n       
    Exception: {[err.__class__.__name__]}\n
    Error: {err}\n
    """,
                    exc_info=exc_info,
                    stack_info=stack_info,
                    stacklevel=stacklevel,
                    extra=extra,
                )
            else:
                super().error(
                    f"""[GLOBAL]
    Message:\n
        {msg}\n       
    """,
                    exc_info=exc_info,
                    stack_info=stack_info,
                    stacklevel=stacklevel,
                    extra=extra,
                )


log = Logger()
