from .logging import log, Logger

__all__ = ["log", "Logger"]
